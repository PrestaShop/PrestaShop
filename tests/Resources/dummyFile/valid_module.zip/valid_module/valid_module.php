<?php

class Valid_Module extends Module
{
    public function __construct()
    {
        $this->name = 'valid_module';
        parent::__construct();
    }
}
