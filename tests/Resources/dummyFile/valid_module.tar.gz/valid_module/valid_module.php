<?php

class Valid_module
{
}
